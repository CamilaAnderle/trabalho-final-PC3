package br.com.prog3.trabalho2.dto;

import br.com.prog3.trabalho2.domain.Marca;
import br.com.prog3.trabalho2.domain.Veiculo;

public class VeiculoDTO {
	private Integer id;
	private String placa;
	private  String cor;
	private  Integer anoModelo;
	private  Marca marca;
	
	public VeiculoDTO(Integer id, String placa, String cor, Integer anoModelo, Marca marca) {
		super();
		this.id = id;
		this.placa = placa;
		this.cor = cor;
		this.anoModelo = anoModelo;
		this.marca = marca;
	}

	public VeiculoDTO(Veiculo veiculo) {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public Integer getAnoModelo() {
		return anoModelo;
	}

	public void setAnoModelo(Integer anoModelo) {
		this.anoModelo = anoModelo;
	}

	public Marca getMarca() {
		return marca;
	}

	public void setMarca(Marca marca) {
		this.marca = marca;
	}
	
	
}
