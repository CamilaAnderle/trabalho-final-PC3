import { Component } from "@angular/core";
import { MarcaService } from "../../marca.service";
import { Marca } from "../../models/marca.model";

@Component({
    selector: 'gv-marca-create',
    templateUrl: './marca-create.component.html'
  })  
export class MarcaCreateComponent {
  sigla!: string;
  descricao!: string;
  
  constructor(private marcaService: MarcaService){}

  save(){
    const marca: Marca = {sigla: this.sigla, descricao: this.descricao};
    this.marcaService.save(marca).subscribe((res) => {
      console.log(res);
    },
    error => console.log(error));
  }
}