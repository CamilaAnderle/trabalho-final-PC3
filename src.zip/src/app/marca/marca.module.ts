import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MarcaCreateComponent } from "./marca-create/component/marca-create.component";
import { NgModule } from "@angular/core";
@NgModule({
imports: [
CommonModule,
FormsModule,
ReactiveFormsModule
],
declarations: [
MarcaCreateComponent
],
exports: [
MarcaCreateComponent
],
})
export class MarcaModule {}