import { CommonModule } from "@angular/common";
import { FormsModule } from '@angular/forms';
import { MarcaCreateComponent } from "./marca-create/component/marca-create.component";
import { NgModule } from "@angular/core";
@NgModule({
imports: [
CommonModule,
FormsModule
],
declarations: [
MarcaCreateComponent
],
exports: [
MarcaCreateComponent
],
})
export class MarcaModule {}