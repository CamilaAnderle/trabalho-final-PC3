export interface Marca {
    id?: number;
    sigla: string;
    descricao: string;
  }