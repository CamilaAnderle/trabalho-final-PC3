import { Component } from '@angular/core';
import { MarcaService } from '../marca.service';
import { Marca } from '../models/marca.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'gv-marca-list',
  standalone: true,
  imports: [],
  templateUrl: './marca-list.component.html',
  styleUrl: './marca-list.component.css'
})
export class MarcaListComponent {
  constructor(private marcaService: MarcaService) { }
  marcas: Marca[] = [];
}
