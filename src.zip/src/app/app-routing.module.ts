import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MarcaCreateComponent } from './marca/marca-create/component/marca-create.component';
import { VeiculoCreateComponent } from './veiculo/veiculo-create/component/veiculo-create.component';
import { HomeComponent } from './componentes/home/home.component';

const routes: Routes = [
  { path: 'marca-create', component: MarcaCreateComponent },
  { path: 'veiculo-create', component: VeiculoCreateComponent },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'home',
    },
    {
    path: 'home',
    component: HomeComponent
    },
    {
      path: 'novo-veiculo',
      component: VeiculoCreateComponent
      },
      {
        path: 'nova-marca',
        component: MarcaCreateComponent
        }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }