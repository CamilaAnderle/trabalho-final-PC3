import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MarcaCreateComponent } from './marca/marca-create/component/marca-create.component';
import { VeiculoCreateComponent } from './veiculo/veiculo-create/component/veiculo-create.component';

const routes: Routes = [
  { path: 'marca-create', component: MarcaCreateComponent },
  { path: 'veiculo-create', component: VeiculoCreateComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }