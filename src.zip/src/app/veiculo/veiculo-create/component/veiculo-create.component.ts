import { Component } from "@angular/core";
import { Veiculo } from "../../models/veiculo.model";
import { VeiculoService } from "../../veiculo.service";
import { Marca } from "../../../marca/models/marca.model";


@Component({
    selector: 'gv-veiculo-create',
    templateUrl: './veiculo-create.component.html'
  })  
export class VeiculoCreateComponent {
  placa!: string;
  cor!: string;
  anoModelo!: number;
  marca!: Marca;
  modalidades = []
  constructor(private veiculoService: VeiculoService){}
  onChange(novoValorMarca: Marca){
        this.marca = novoValorMarca;
    }
  save(){
    const veiculo: Veiculo = {placa: this.placa, cor: this.cor, anoModelo: this.anoModelo , marca: this.marca};
    this.veiculoService.save(veiculo).subscribe((res) => {
      console.log(res);
    },
    error => console.log(error));
  }
}
