import { Component } from '@angular/core';
import { VeiculoService } from '../veiculo.service';
import { Veiculo } from '../models/veiculo.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'gv-veiculo-list',
  standalone: true,
  imports: [],
  templateUrl: './veiculo-list.component.html',
  styleUrl: './veiculo-list.component.css'
})
export class VeiculoListComponent {
  constructor(private veiculoService: VeiculoService) { }
  veiculos: Veiculo[] = [];
}
